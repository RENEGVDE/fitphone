import React from 'react';

const Room = () =>{
    return(
        <h1>Room</h1>
    )
}
export default Room