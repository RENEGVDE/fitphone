import "../../styles/_login.scss";

const Login = () => {
  return (
    <div className="login">
      <div className="login-text-wrapper">
        <h3 className="login__title">Sign in to Agreement</h3>
        <span className="login__description">
          Sign in to Agreement or create an account.
        </span>
      </div>

      <form className="login-forum">
        <div className="textbox-holder">
          <label className="label-box" for="username">
            Username
          </label>
          <input
            className="text-box"
            type="text"
            id="username"
            name="username"
            //placeholder="Username"
          ></input>
        </div>
        <div className="textbox-holder">
          <label className="label-box" for="Password">
            Password
          </label>
          <input
            className="text-box"
            type="password"
            id="password"
            name="password"
            // placeholder="Password"
          ></input>
        </div>
      </form>
    </div>
  );
};

export default Login;
