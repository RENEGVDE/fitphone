import React from 'react';
import { Container, Col, Row, Image, Button, Alert, Badge } from 'react-bootstrap';

const User = ({ user, name }) => {

    let isThisCurrentUser = true

    // const trimmedUser = name.trim().toLowerCase();
    // if (user === trimmedName) {
    //     isThisCurrentUser = true;
    // }


    return (
        isThisCurrentUser
            ? (
                <div className='user_container'>
                    <Image fluid src="boy.png" roundedCircle />
                    <span><center>{name}</center></span>
                </div>
            )
            :
            (
                <div className='user_container'>
                    <Image fluid src="boy.png" roundedCircle />
                    <span><center>{name}</center></span>
                </div>
            )
    )

}
export default User