import React, { Component } from 'react';

import { Navbar,Nav,Form,Button } from 'react-bootstrap';


class FooterBar extends Component {
    state = {  }
    render() { 
        return ( 
        <Navbar fixed="bottom" bg="dark" variant="dark">
        <Nav className="mr-auto">
          <Nav.Link href="/insight">Insight</Nav.Link>
          <Nav.Link href="/fiends">Firends</Nav.Link>
          <Nav.Link href="/signup">Signup</Nav.Link>
        </Nav>
      </Navbar> );
    }  
}
 
export default FooterBar;