import React, { useState, useEffect } from "react";
import queryString from "query-string";
import io from "socket.io-client";

import Users from "../Users/Users";
import "../../styles/_register.scss";
import "../../styles/_login.scss";
import "../../styles/_agreement.scss";

import Clock from "./Clock/Clock";

import {
  Container,
  Col,
  Row,
  Image,
  Button,
  Alert,
  Badge,
} from "react-bootstrap";

let socket;

const Agreement = ({ location }) => {
  const [name, setName] = useState("");
  const [room, setRoom] = useState("");

  const [users, setUsers] = useState("");

  const [min, setMin] = useState("");
  const [hour, setHour] = useState("");

  const ENDPOINT = "localhost:5000";

  var connectionOptions = {
    "force new connection": true,
    reconnectionAttempts: "Infinity",
    timeout: 10000,
    transports: ["websocket"],
  };
  useEffect(() => {
    const { name, room, hour, min } = queryString.parse(location.search);

    socket = io.connect(ENDPOINT, connectionOptions);
    setName(name);
    setRoom(room);

    setHour(hour);
    setMin(min);

    console.log(users);

    socket.emit("join", { name, room }, (error) => {
      if (error) {
        alert(error);
      }
    });
  }, [ENDPOINT, location.search]);

  useEffect(() => {
    socket.on("roomData", ({ users }) => {
      setUsers(users);
    });
  }, []);

  return (
    <div className="lobby">
      <div className="lobby-wrapper">
        <div className="lobby-icons-wrapper">
          <img
            src="/icons/white-arrow-back.png"
            alt=""
            className="lobby__icon"
          />
          <img src="/icons/white-close.png" alt="" className="lobby__icon" />
        </div>
        <div className="lobby-clock">timer</div>
        <div className="user-container">
          <Users users={users} name={name} />
        </div>
        Agreement: {room}
        <div className="lobby-info-wrapper">
          <p>Agreemnt info lorem ipsum </p>
        </div>
      </div>
      <div className="bottom-decoration-wrapper">
        <img
          className="bottom-decoration"
          src="/decorations/Bottom-decoration.png"
          alt=""
        />
      </div>
    </div>
  );
};
export default Agreement;

//
