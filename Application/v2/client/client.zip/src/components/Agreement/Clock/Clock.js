import React, { useState, useEffect } from 'react';
import './Clock.css'
const Clock = ({  }) => {
   
  const hour =0;
  const min=0;
  const sec=0;
  
  
    
   
   
    return(
        <div className='clock-outer'>

        <div class="clock-container">
        
        <div class="clock-col">

        <p class="clock-hours clock-timer">87</p>

        <p class="clock-label">
            Hours
          </p>
        </div>
        <div class="clock-col">
            <p class="coma">:</p>
        </div>
        <div class="clock-col">

        <p class="clock-hours clock-timer">87</p>

        <p class="clock-label">
            Minutes
          </p>
        </div>
      </div>

        </div>
        
    )
}


export default Clock