import React from 'react';
import "../../styles/_register.scss";
import "../../styles/_login.scss";
import "../../styles/_results.scss";

const Results = () => {

    const res = false

    return (
        res ? (
            <div className='mainResultContainer'>
                <div className='MainTextContainer'>
                    <h2>Great</h2>
                    <p>You finnished the agreement successfully</p>
                </div>
                <div className='timing'>
                    <p>Time off phone:</p>
                    <h2>1 <t>Hour</t> 20 <t>Minutes</t></h2>
                </div>
                <button className='btn btn-success resButton'>Continue </button>

            </div>
        )
            :
            (
                <div className='DmainResultContainer'>
                    <div className='DMainTextContainer'>
                        <h2>Oh No!!</h2>
                        <p>You did not finnished the agreement successfully</p>
                    </div>
                    <div className='Dtiming'>
                        <p>Time off phone:</p>
                        <h2>1 <t>Hour</t> 20 <t>Minutes</t></h2>
                    </div>
                    <button className='btn btn-danger DresButton' >Continue </button>

                </div>
            )
    )


}
export default Results