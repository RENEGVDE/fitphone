import React from "react";

import "./App.css";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Join from "./components/Join/Join";
import Results from "./components/Results/Results";

import Create from "./components/Create/create";
import Agreement from "./components/Agreement/Agreement";
// import FooterBar from './components/footer'
import { Container } from "react-bootstrap";
import Signup from "./components/Signup";
import Login from "./components/Login";
import Profile from "./components/Profile";
import PrivateRoute from "./components/PrivateRoute";
import { AuthProvider } from "./contexts/AuthContext";

const App = () => (
  <div>
    <Router>
      <Route path="/" exact component={Join} />
      <Route path="/Create" exact component={Create} />
      <Route path="/Agreement" exact component={Agreement} />
      <AuthProvider>
        <Switch>
          <PrivateRoute path="/profile" component={Profile} />
          <Route path="/signup" component={Signup} />
          <Route path="/login" component={Login} />
          <Route path="/Results" component={Results} />
        </Switch>
      </AuthProvider>
    </Router>
    {/* <FooterBar /> */}
  </div>
);

export default App;
